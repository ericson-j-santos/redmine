Coloque aqui os arquivos .yml de templates de issues do Redmine.
Exemplo:
  - epic_discovery.yml
  - feature_delivery_backend.yml
  - feature_delivery_frontend.yml
  - bug_scale.yml
  - task_default.yml

Eles serão copiados para:
  /usr/src/redmine/plugins/redmine_issue_templates/templates/
dentro do container Redmine.
