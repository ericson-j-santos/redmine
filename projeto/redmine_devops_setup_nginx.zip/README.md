# Redmine DevOps Setup + Nginx Reverse Proxy + HTTPS (Let's Encrypt)

Este bundle adiciona ao setup anterior:

- Nginx como reverse proxy na frente do Redmine
- Publicação em HTTP (80) e HTTPS (443)
- Integração com certificados gerados via **certbot** no host Debian

## 1. Estrutura

- `docker-compose.yml`
  - `db` (Postgres)
  - `redmine` (build ./redmine)
  - `nginx` (reverse proxy)
- `redmine/Dockerfile`
  - Redmine 5.1 + plugin `redmine_issue_templates`
  - cópia de templates YAML para o plugin
- `redmine/templates/`
  - pasta para você colocar os `.yml` dos templates de issues
- `nginx/conf.d/redmine.conf`
  - vhost com HTTP → HTTPS e proxy para Redmine
- `scripts/bootstrap_redmine_with_nginx.sh`
  - sobe stack e roda migração do plugin
- `scripts/generate_certbot_certs_example.sh`
  - exemplo de como gerar certificados via certbot no host Debian

## 2. Passo a passo resumido (Debian 12 / servidor próprio)

### 2.1. Pré-requisitos

- Docker + Docker Compose
- Domínio apontando (A / CNAME) para o IP do servidor
- Porta 80 e 443 liberadas externamente

### 2.2. Geração de certificados (modelo simples com certbot standalone)

1. Ajuste o domínio:

   ```bash
   cd redmine_devops_setup_nginx
   sed -i 's/SEU_DOMINIO_AQUI/seu.dominio.com/g' nginx/conf.d/redmine.conf
   sed -i 's/SEU_DOMINIO_AQUI/seu.dominio.com/g' scripts/generate_certbot_certs_example.sh
   ```

2. Gere os certificados no host (fora do Docker):

   ```bash
   ./scripts/generate_certbot_certs_example.sh
   ```

   Isso vai:
   - derrubar a stack (se estiver de pé)
   - rodar `certbot certonly --standalone -d seu.dominio.com`
   - criar certificados em `/etc/letsencrypt/live/seu.dominio.com/`

3. Confirme os arquivos:

   - `/etc/letsencrypt/live/seu.dominio.com/fullchain.pem`
   - `/etc/letsencrypt/live/seu.dominio.com/privkey.pem`

### 2.3. Subir a stack com Nginx + Redmine

```bash
./scripts/bootstrap_redmine_with_nginx.sh
```

- Redmine ficará acessível em:
  - `https://seu.dominio.com` (após certificados)
  - `http://seu.dominio.com` (redirecionando para HTTPS)

### 2.4. Sobre o volume /etc/letsencrypt

No `docker-compose.yml`:

```yaml
volumes:
  - /etc/letsencrypt:/etc/letsencrypt:ro
```

Isso monta os certificados gerados pelo `certbot` do host dentro do container Nginx:

- `/etc/letsencrypt/live/seu.dominio.com/fullchain.pem`
- `/etc/letsencrypt/live/seu.dominio.com/privkey.pem`

O `nginx/conf.d/redmine.conf` já referencia esses caminhos.

## 3. Fluxo operacional recomendado

1. Configurar DNS → IP do servidor
2. Gerar certificados com `certbot` (script de exemplo)
3. Subir stack com `bootstrap_redmine_with_nginx.sh`
4. Acessar `https://seu.dominio.com`
5. Ajustar:
   - usuários
   - trackers
   - campos customizados (ex.: `Fase`)
   - importar CSV de backlog (Discovery → Delivery → Scale)

## 4. Próximos incrementos possíveis

- Renovação automática de certificados (cron `certbot renew`)
- Rate limiting / proteção básica no Nginx
- Proxy para múltiplas apps (ex.: Redmine + CPF Contatos docs)
- Observabilidade (logs estruturados do Nginx → Loki/Elastic/Grafana)

