#!/usr/bin/env bash
set -e

echo "[INFO] Construindo imagens (Redmine customizado + Nginx)..."
docker compose build

echo "[INFO] Subindo stack (db + redmine + nginx)..."
docker compose up -d

echo "[INFO] Aguardando containers subirem..."
sleep 25

echo "[INFO] Executando migração do plugin redmine_issue_templates..."
docker compose exec redmine bundle exec rake redmine:plugins:migrate NAME=redmine_issue_templates RAILS_ENV=production

echo "[INFO] Ambiente inicial pronto."
echo " - Redmine por trás do Nginx em http://SEU_DOMINIO_AQUI ou https://SEU_DOMINIO_AQUI (após certificados)."
