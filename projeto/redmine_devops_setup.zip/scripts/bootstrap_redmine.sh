#!/usr/bin/env bash
set -e

echo "[INFO] Subindo stack Redmine + Postgres..."
docker compose up -d

echo "[INFO] Aguardando containers subirem..."
sleep 20

echo "[INFO] Executando migração do plugin redmine_issue_templates..."
docker compose exec redmine bundle exec rake redmine:plugins:migrate NAME=redmine_issue_templates RAILS_ENV=production

echo "[INFO] Pronto. Acesse: http://localhost:3000"
echo "Usuário padrão: admin / admin (se imagem original não tiver sido alterada)."
