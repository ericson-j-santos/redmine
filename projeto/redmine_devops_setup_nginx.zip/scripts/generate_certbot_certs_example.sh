#!/usr/bin/env bash
set -e

DOMINIO="SEU_DOMINIO_AQUI"

echo "[INFO] Este script é um exemplo. Execute no HOST Debian (fora do Docker)."
echo "[INFO] Garanta que a porta 80 esteja livre e apontando para este servidor."

echo "[INFO] Parando stack para liberar porta 80..."
docker compose down

echo "[INFO] Rodando certbot em modo standalone..."
sudo certbot certonly --standalone -d "$DOMINIO"

echo "[INFO] Certificados gerados em /etc/letsencrypt/live/$DOMINIO/"
echo "[INFO] Agora ajuste nginx/conf.d/redmine.conf com o domínio correto."
echo "[INFO] Depois suba novamente a stack:"
echo "  docker compose up -d"
