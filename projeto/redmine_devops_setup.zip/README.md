# Redmine DevOps Setup – Issue Templates + Discovery → Delivery → Scale

Este bundle prepara um ambiente Redmine com:

- Postgres
- Redmine (imagem oficial)
- Plugin **redmine_issue_templates**
- Templates YAML prontos para:
  - Epic Discovery
  - Feature Backend
  - Feature Frontend
  - Bug Scale
  - Task Default

## 1. Pré-requisitos

- Docker
- Docker Compose (plugin `docker compose`)
- Porta 3000 livre

## 2. Estrutura

- `docker-compose.yml` – orquestra Redmine + Postgres
- `redmine/Dockerfile` – imagem Redmine customizada com:
  - git
  - plugin `redmine_issue_templates` clonado
  - templates YAML copiados
- `redmine/templates/` – templates YAML Discovery → Delivery → Scale
- `scripts/bootstrap_redmine.sh` – script para subir stack e rodar migração do plugin

## 3. Como subir o ambiente

```bash
cd redmine_devops_setup
# construir e subir
docker compose build
./scripts/bootstrap_redmine.sh
```

Isso vai:

1. Subir Postgres + Redmine
2. Executar `rake redmine:plugins:migrate NAME=redmine_issue_templates`
3. Deixar o Redmine pronto em `http://localhost:3000`

Usuário inicial padrão (imagem oficial Redmine):

- user: `admin`
- pass: `admin` (você será forçado a trocar no primeiro login)

## 4. Como os templates funcionam

O Dockerfile copia os YAML em:

```text
/usr/src/redmine/plugins/redmine_issue_templates/templates/
```

O plugin `redmine_issue_templates` lê essa pasta como repositório de templates.

Dentro do Redmine:

- Vá em **Administração → Plugins** e confirme que `redmine_issue_templates` está listado.
- Vá em **Administração → Issue templates** (ou Configurações por projeto) para visualizar/ajustar os templates.

## 5. Ajustes para produção (Debian 12 / VPS)

- Trocar senha do banco (`POSTGRES_PASSWORD`) no `docker-compose.yml`
- Trocar `REDMINE_SECRET_KEY_BASE`
- Configurar backup de volume:
  - `db_data`
  - `redmine_files`
- Colocar Nginx/Apache na frente caso queira HTTPS.

## 6. Uso com governança Discovery → Delivery → Scale

- Use:
  - `Epic Discovery` para abrir EPICs estratégicas
  - `Feature Backend` para histórias de backend
  - `Feature Frontend` para telas/fluxos Vue
  - `Bug Escalável` para bugs com impacto produtivo
  - `Task Default` para atividades operacionais

Com isso, o Redmine passa a refletir o mesmo modelo de quadro que você já montou para a Proposta Suite.
